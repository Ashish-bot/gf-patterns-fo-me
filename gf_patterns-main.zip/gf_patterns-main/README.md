# gf_patterns
Some predefined gf patterns by [1ndianl33t](https://github.com/1ndianl33t/Gf-Patterns) and [tomnomnom](https://github.com/tomnomnom/gf/tree/master/examples) to use with [gf](https://github.com/tomnomnom/gf) tool. 



# Credit
[![Twitter URL](https://img.shields.io/twitter/url/https/twitter.com/bukotsunikki.svg?style=social&label=Follow%20%401ndianl33t)](https://twitter.com/1ndianl33t)  :handshake:  [![Twitter URL](https://img.shields.io/twitter/url/https/twitter.com/bukotsunikki.svg?style=social&label=Follow%20%40TomNomNom)](https://twitter.com/TomNomNom)
